<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>LABIFY LOGIN</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>
  
<div class="form" id="form">
  <div class="field email">
    <div class="icon"></div>
    <input class="input" id="email" type="email" placeholder="Username or Email" autocomplete="off"/>
  </div>
  <div class="field password">
    <div class="icon"></div>
    <input class="input" id="password" type="password" placeholder="Password"/>
  </div>
  <button class="button" id="submit">LOGIN
    <div class="side-top-bottom"></div>
    <div class="side-left-right"></div>
  </button><small>Fill in the form</small>
 <a href="/Eproject3rdSem/Labifywebpage/Index.php"> <button class="button" id="submit">BACK
    <div class="side-top-bottom"></div>
    <div class="side-left-right"></div>
  </button></a>
</div>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>
<?php


if (isset($_POST['btnsignin'])) {

$user_name=$_POST['uname'];
$user_pass=$_POST['upass'];

$q="SELECT * FROM `teacher` WHERE 	TeacherName='$user_name' and 	Teacherpass='$user_pass' ";

$login=mysqli_query($con,$q);
 
if (mysqli_num_rows($login)!=0) {
	$_SESSION['ADMIN']=$user_name;
	
	echo"<script>alert('Login successful');window.location.href='profile.php'</script>";

}
else{
	echo"<script>alert('Login Failed')</script>";
}
}

?>