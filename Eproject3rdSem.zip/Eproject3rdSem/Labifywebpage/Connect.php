<?php

$con=mysqli_connect("localhost","root","","labify");
if(!$con)
{   echo"<script>alert('Connection Failed')</script>";
}
else{
    
}

?>