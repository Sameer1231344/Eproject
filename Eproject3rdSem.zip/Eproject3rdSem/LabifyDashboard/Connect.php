<?php

$con=mysqli_connect("localhost","root","","Labify");
if(!$con)
{   echo"<script>alert('Connection Failed')</script>";
}
else{
    
}

?>