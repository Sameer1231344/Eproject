<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Dashtreme Admin - Free Dashboard for Bootstrap 4 by Codervent</title>
  <!-- loader-->
  <link href="assets/css/pace.min.css" rel="stylesheet"/>
  <script src="assets/js/pace.min.js"></script>
  <!--favicon-->
  <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">
  <!-- simplebar CSS-->
  <link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="assets/css/app-style.css" rel="stylesheet"/>
  
</head>

<body class="bg-theme bg-theme5">

<!-- start loader -->
<div id="pageloader-overlay" class="visible incoming"><div class="loader-wrapper-outer"><div class="loader-wrapper-inner" ><div class="loader"></div></div></div></div>
   <!-- end loader -->

<!-- Start wrapper-->
 <div id="wrapper">

 <!--Start sidebar-wrapper-->
   <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
      <a href="index.php">
      <img src="assets/images/lmslogo.png" class="logo-icon" alt="logo icon">
       <h5 class="logo-text">LMS </h5>
     </a>
   </div>
   <ul class="sidebar-menu do-nicescrol">
      <li class="sidebar-header">MAIN NAVIGATION</li>
      <li>
        <a href="index.php">
          <i class="zmdi zmdi-view-dashboard"></i> <span>Dashboard</span>
        </a>
      </li>

      

      <li>
      
      <a class="nav-link dropdown-toggle dropdown-toggle-nocaret waves-effect" data-toggle="dropdown" href="javascript:void();"><i class="zmdi zmdi-format-list-bulleted"></i> <span>Forms</span></a>
      <ul class="dropdown-menu dropdown-menu-right">
      <a href="Curriculumform.php"> <li class="dropdown-item"> Currriculum</li></a>
      <a href="Batchform.php"> <li class="dropdown-item"> Batch</li></a>
      <a href="Courseotlineform.php"> <li class="dropdown-item"> Course</li></a>
      <a href="teacherform.php"> <li class="dropdown-item"> Teachers</li></a>
      <a href="studentform.php"> <li class="dropdown-item"> Students</li></a>
        </ul>
      </li>

      <li>
        <a href="tables.php">
          <i class="zmdi zmdi-grid"></i> <span>Tables</span>
        </a>
      </li>

      

      <li>
        <a href="profile.php">
          <i class="zmdi zmdi-face"></i> <span>Profile</span>
        </a>
      </li>

      <li>
        <a href="login.php" target="_blank">
          <i class="zmdi zmdi-lock"></i> <span>Login</span>
        </a>
      </li>

       <li>
        <a href="register.php" target="_blank">
          <i class="zmdi zmdi-account-circle"></i> <span>Registration</span>
        </a>
      </li>
	  
      <li class="sidebar-header">LABELS</li>
      <li><a href="javaScript:void();"><i class="zmdi zmdi-coffee text-danger"></i> <span>Important</span></a></li>
      <li><a href="javaScript:void();"><i class="zmdi zmdi-chart-donut text-success"></i> <span>Warning</span></a></li>
      <li><a href="javaScript:void();"><i class="zmdi zmdi-share text-info"></i> <span>Information</span></a></li>

    </ul>
   
   </div>
   <!--End sidebar-wrapper-->
  

<!--Start topbar header-->
<header class="topbar-nav">
 <nav class="navbar navbar-expand fixed-top">
  <ul class="navbar-nav mr-auto align-items-center">
    <li class="nav-item">
      <a class="nav-link toggle-menu" href="javascript:void();">
       <i class="icon-menu menu-icon"></i>
     </a>
    </li>
    <li class="nav-item">
      <form class="search-bar">
        <input type="text" class="form-control" placeholder="Enter keywords">
         <a href="javascript:void();"><i class="icon-magnifier"></i></a>
      </form>
    </li>
  </ul>
     
  <ul class="navbar-nav align-items-center right-nav-link">
    <li class="nav-item dropdown-lg">
      <a class="nav-link dropdown-toggle dropdown-toggle-nocaret waves-effect" data-toggle="dropdown" href="javascript:void();">
      <i class="fa fa-envelope-open-o"></i></a>
    </li>
    <li class="nav-item dropdown-lg">
      <a class="nav-link dropdown-toggle dropdown-toggle-nocaret waves-effect" data-toggle="dropdown" href="javascript:void();">
      <i class="fa fa-bell-o"></i></a>
    </li>
    <li class="nav-item language">
      <a class="nav-link dropdown-toggle dropdown-toggle-nocaret waves-effect" data-toggle="dropdown" href="javascript:void();"><i class="fa fa-flag"></i></a>
      <ul class="dropdown-menu dropdown-menu-right">
          <li class="dropdown-item"> <i class="flag-icon flag-icon-gb mr-2"></i> English</li>
          <li class="dropdown-item"> <i class="flag-icon flag-icon-fr mr-2"></i> French</li>
          <li class="dropdown-item"> <i class="flag-icon flag-icon-cn mr-2"></i> Chinese</li>
          <li class="dropdown-item"> <i class="flag-icon flag-icon-de mr-2"></i> German</li>
        </ul>
    </li>
    <li class="nav-item">
      <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown" href="#">
        <span class="user-profile"><img src="https://via.placeholder.com/110x110" class="img-circle" alt="user avatar"></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-right">
       <li class="dropdown-item user-details">
        <a href="javaScript:void();">
           <div class="media">
             <div class="avatar"><img class="align-self-start mr-3" src="https://via.placeholder.com/110x110" alt="user avatar"></div>
            <div class="media-body">
            <h6 class="mt-2 user-title">Sarajhon Mccoy</h6>
            <p class="user-subtitle">mccoy@example.com</p>
            </div>
           </div>
          </a>
        </li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><i class="icon-envelope mr-2"></i> Inbox</li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><i class="icon-wallet mr-2"></i> Account</li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><i class="icon-settings mr-2"></i> Setting</li>
        <li class="dropdown-divider"></li>
        <li class="dropdown-item"><i class="icon-power mr-2"></i> Logout</li>
      </ul>
    </li>
  </ul>
</nav>
</header>
<!--End topbar header-->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">

   <div class="row mt-3">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">

          <div class="row">
            <div class="col-lg-6 col-xl-3 icon">
              <a data-code="f3e9" data-name="group" href="javascript:void();"><i class="zmdi zmdi-group"></i> <span>group</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon">
              <a data-code="f3ea" data-name="rss" href="javascript:void();"><i class="zmdi zmdi-rss"></i> <span>rss</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3eb" data-name="shape">
              <a href="javascript:void();"><i class="zmdi zmdi-shape"></i> <span>shape</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3ec" data-name="spinner">
              <a href="javascript:void();"><i class="zmdi zmdi-spinner"></i> <span>spinner</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3ed" data-name="ungroup">
              <a href="javascript:void();"><i class="zmdi zmdi-ungroup"></i> <span>ungroup</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3ee" data-name="500px">
              <a href="javascript:void();"><i class="zmdi zmdi-500px"></i> <span>500px</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3ef" data-name="8tracks">
              <a href="javascript:void();"><i class="zmdi zmdi-8tracks"></i> <span>8tracks</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3f0" data-name="amazon">
              <a href="javascript:void();"><i class="zmdi zmdi-amazon"></i> <span>amazon</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3f1" data-name="blogger">
              <a href="javascript:void();"><i class="zmdi zmdi-blogger"></i> <span>blogger</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3f2" data-name="delicious">
              <a href="javascript:void();"><i class="zmdi zmdi-delicious"></i> <span>delicious</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3f3" data-name="disqus">
              <a href="javascript:void();"><i class="zmdi zmdi-disqus"></i> <span>disqus</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3f4" data-name="flattr">
              <a href="javascript:void();"><i class="zmdi zmdi-flattr"></i> <span>flattr</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3f5" data-name="flickr">
              <a href="javascript:void();"><i class="zmdi zmdi-flickr"></i> <span>flickr</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3f6" data-name="github-alt">
              <a href="javascript:void();"><i class="zmdi zmdi-github-alt"></i> <span>github-alt</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3f7" data-name="google-old">
              <a href="javascript:void();"><i class="zmdi zmdi-google-old"></i> <span>google-old</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3f8" data-name="linkedin">
              <a href="javascript:void();"><i class="zmdi zmdi-linkedin"></i> <span>linkedin</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3f9" data-name="odnoklassniki">
              <a href="javascript:void();"><i class="zmdi zmdi-odnoklassniki"></i> <span>odnoklassniki</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3fa" data-name="outlook">
              <a href="javascript:void();"><i class="zmdi zmdi-outlook"></i> <span>outlook</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3fb" data-name="paypal-alt">
              <a href="javascript:void();"><i class="zmdi zmdi-paypal-alt"></i> <span>paypal-alt</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3fc" data-name="pinterest">
              <a href="javascript:void();"><i class="zmdi zmdi-pinterest"></i> <span>pinterest</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3fd" data-name="playstation">
              <a href="javascript:void();"><i class="zmdi zmdi-playstation"></i> <span>playstation</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3fe" data-name="reddit">
              <a href="javascript:void();"><i class="zmdi zmdi-reddit"></i> <span>reddit</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f3ff" data-name="skype">
              <a href="javascript:void();"><i class="zmdi zmdi-skype"></i> <span>skype</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f400" data-name="slideshare">
              <a href="javascript:void();"><i class="zmdi zmdi-slideshare"></i> <span>slideshare</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f401" data-name="soundcloud">
              <a href="javascript:void();"><i class="zmdi zmdi-soundcloud"></i> <span>soundcloud</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f402" data-name="tumblr">
              <a href="javascript:void();"><i class="zmdi zmdi-tumblr"></i> <span>tumblr</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f403" data-name="twitch">
              <a href="javascript:void();"><i class="zmdi zmdi-twitch"></i> <span>twitch</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f404" data-name="vimeo">
              <a href="javascript:void();"><i class="zmdi zmdi-vimeo"></i> <span>vimeo</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f405" data-name="whatsapp">
              <a href="javascript:void();"><i class="zmdi zmdi-whatsapp"></i> <span>whatsapp</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f406" data-name="xbox">
              <a href="javascript:void();"><i class="zmdi zmdi-xbox"></i> <span>xbox</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f407" data-name="yahoo">
              <a href="javascript:void();"><i class="zmdi zmdi-yahoo"></i> <span>yahoo</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f408" data-name="youtube-play">
              <a href="javascript:void();"><i class="zmdi zmdi-youtube-play"></i> <span>youtube-play</span></a>
            </div>
            <div class="col-lg-6 col-xl-3 icon" data-code="f409" data-name="youtube">
              <a href="javascript:void();"><i class="zmdi zmdi-youtube"></i> <span>youtube</span></a>
            </div>
          </div><!--End Row-->
        
          <div class="row">
            <div class="icon col-sm-3" data-code="f34e" data-name="google">
              <a href="javascript:void();"><i class="zmdi zmdi-google"></i> <span>google</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f34c" data-name="google-plus-box">
              <a href="javascript:void();"><i class="zmdi zmdi-google-plus-box"></i> <span>google-plus-box</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f34d" data-name="google-plus">
              <a href="javascript:void();"><i class="zmdi zmdi-google-plus"></i> <span>google-plus</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f357" data-name="paypal">
              <a href="javascript:void();"><i class="zmdi zmdi-paypal"></i> <span>paypal</span></a>
            </div>
          </div>
          <h4>Web Application</h4>
          <hr>
          <div class="row">
            <div class="icon col-sm-3" data-code="f101" data-name="3d-rotation">
              <a href="javascript:void();"><i class="zmdi zmdi-3d-rotation"></i> <span>3d-rotation</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f102" data-name="airplane-off">
              <a href="javascript:void();"><i class="zmdi zmdi-airplane-off"></i> <span>airplane-off</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f103" data-name="airplane">
              <a href="javascript:void();"><i class="zmdi zmdi-airplane"></i> <span>airplane</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f104" data-name="album">
              <a href="javascript:void();"><i class="zmdi zmdi-album"></i> <span>album</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f105" data-name="archive">
              <a href="javascript:void();"><i class="zmdi zmdi-archive"></i> <span>archive</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f106" data-name="assignment-account">
              <a href="javascript:void();"><i class="zmdi zmdi-assignment-account"></i> <span>assignment-account</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f107" data-name="assignment-alert">
              <a href="javascript:void();"><i class="zmdi zmdi-assignment-alert"></i> <span>assignment-alert</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f108" data-name="assignment-check">
              <a href="javascript:void();"><i class="zmdi zmdi-assignment-check"></i> <span>assignment-check</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f109" data-name="assignment-o">
              <a href="javascript:void();"><i class="zmdi zmdi-assignment-o"></i> <span>assignment-o</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f10a" data-name="assignment-return">
              <a href="javascript:void();"><i class="zmdi zmdi-assignment-return"></i> <span>assignment-return</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f10b" data-name="assignment-returned">
              <a href="javascript:void();"><i class="zmdi zmdi-assignment-returned"></i> <span>assignment-returned</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f10c" data-name="assignment">
              <a href="javascript:void();"><i class="zmdi zmdi-assignment"></i> <span>assignment</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f10d" data-name="attachment-alt">
              <a href="javascript:void();"><i class="zmdi zmdi-attachment-alt"></i> <span>attachment-alt</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f10e" data-name="attachment">
              <a href="javascript:void();"><i class="zmdi zmdi-attachment"></i> <span>attachment</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f10f" data-name="audio">
              <a href="javascript:void();"><i class="zmdi zmdi-audio"></i> <span>audio</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f110" data-name="badge-check">
              <a href="javascript:void();"><i class="zmdi zmdi-badge-check"></i> <span>badge-check</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f111" data-name="balance-wallet">
              <a href="javascript:void();"><i class="zmdi zmdi-balance-wallet"></i> <span>balance-wallet</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f112" data-name="balance">
              <a href="javascript:void();"><i class="zmdi zmdi-balance"></i> <span>balance</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f113" data-name="battery-alert">
              <a href="javascript:void();"><i class="zmdi zmdi-battery-alert"></i> <span>battery-alert</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f114" data-name="battery-flash">
              <a href="javascript:void();"><i class="zmdi zmdi-battery-flash"></i> <span>battery-flash</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f115" data-name="battery-unknown">
              <a href="javascript:void();"><i class="zmdi zmdi-battery-unknown"></i> <span>battery-unknown</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f116" data-name="battery">
              <a href="javascript:void();"><i class="zmdi zmdi-battery"></i> <span>battery</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f117" data-name="bike">
              <a href="javascript:void();"><i class="zmdi zmdi-bike"></i> <span>bike</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f118" data-name="block-alt">
              <a href="javascript:void();"><i class="zmdi zmdi-block-alt"></i> <span>block-alt</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f119" data-name="block">
              <a href="javascript:void();"><i class="zmdi zmdi-block"></i> <span>block</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f11a" data-name="boat">
              <a href="javascript:void();"><i class="zmdi zmdi-boat"></i> <span>boat</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f11b" data-name="book-image">
              <a href="javascript:void();"><i class="zmdi zmdi-book-image"></i> <span>book-image</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f11c" data-name="book">
              <a href="javascript:void();"><i class="zmdi zmdi-book"></i> <span>book</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f11d" data-name="bookmark-outline">
              <a href="javascript:void();"><i class="zmdi zmdi-bookmark-outline"></i> <span>bookmark-outline</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f11e" data-name="bookmark">
              <a href="javascript:void();"><i class="zmdi zmdi-bookmark"></i> <span>bookmark</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f11f" data-name="brush">
              <a href="javascript:void();"><i class="zmdi zmdi-brush"></i> <span>brush</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f120" data-name="bug">
              <a href="javascript:void();"><i class="zmdi zmdi-bug"></i> <span>bug</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f121" data-name="bus">
              <a href="javascript:void();"><i class="zmdi zmdi-bus"></i> <span>bus</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f122" data-name="cake">
              <a href="javascript:void();"><i class="zmdi zmdi-cake"></i> <span>cake</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f123" data-name="car-taxi">
              <a href="javascript:void();"><i class="zmdi zmdi-car-taxi"></i> <span>car-taxi</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f124" data-name="car-wash">
              <a href="javascript:void();"><i class="zmdi zmdi-car-wash"></i> <span>car-wash</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f125" data-name="car">
              <a href="javascript:void();"><i class="zmdi zmdi-car"></i> <span>car</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f126" data-name="card-giftcard">
              <a href="javascript:void();"><i class="zmdi zmdi-card-giftcard"></i> <span>card-giftcard</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f127" data-name="card-membership">
              <a href="javascript:void();"><i class="zmdi zmdi-card-membership"></i> <span>card-membership</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f128" data-name="card-travel">
              <a href="javascript:void();"><i class="zmdi zmdi-card-travel"></i> <span>card-travel</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f129" data-name="card">
              <a href="javascript:void();"><i class="zmdi zmdi-card"></i> <span>card</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f12a" data-name="case-check">
              <a href="javascript:void();"><i class="zmdi zmdi-case-check"></i> <span>case-check</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f12b" data-name="case-download">
              <a href="javascript:void();"><i class="zmdi zmdi-case-download"></i> <span>case-download</span></a>
            </div>

          </div>
          <h4>Notifications</h4>
          <hr>
          <div class="row">
            <div class="icon col-sm-3" data-code="f1f0" data-name="alert-circle-o">
              <a href="javascript:void();"><i class="zmdi zmdi-alert-circle-o"></i> <span>alert-circle-o</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1f1" data-name="alert-circle">
              <a href="javascript:void();"><i class="zmdi zmdi-alert-circle"></i> <span>alert-circle</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1f2" data-name="alert-octagon">
              <a href="javascript:void();"><i class="zmdi zmdi-alert-octagon"></i> <span>alert-octagon</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1f3" data-name="alert-polygon">
              <a href="javascript:void();"><i class="zmdi zmdi-alert-polygon"></i> <span>alert-polygon</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1f4" data-name="alert-triangle">
              <a href="javascript:void();"><i class="zmdi zmdi-alert-triangle"></i> <span>alert-triangle</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1f5" data-name="help-outline">
              <a href="javascript:void();"><i class="zmdi zmdi-help-outline"></i> <span>help-outline</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1f6" data-name="help">
              <a href="javascript:void();"><i class="zmdi zmdi-help"></i> <span>help</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1f7" data-name="info-outline">
              <a href="javascript:void();"><i class="zmdi zmdi-info-outline"></i> <span>info-outline</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1f8" data-name="info">
              <a href="javascript:void();"><i class="zmdi zmdi-info"></i> <span>info</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1f9" data-name="notifications-active">
              <a href="javascript:void();"><i class="zmdi zmdi-notifications-active"></i> <span>notifications-active</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1fa" data-name="notifications-add">
              <a href="javascript:void();"><i class="zmdi zmdi-notifications-add"></i> <span>notifications-add</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1fb" data-name="notifications-none">
              <a href="javascript:void();"><i class="zmdi zmdi-notifications-none"></i> <span>notifications-none</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1fc" data-name="notifications-off">
              <a href="javascript:void();"><i class="zmdi zmdi-notifications-off"></i> <span>notifications-off</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1fd" data-name="notifications-paused">
              <a href="javascript:void();"><i class="zmdi zmdi-notifications-paused"></i> <span>notifications-paused</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f1fe" data-name="notifications">
              <a href="javascript:void();"><i class="zmdi zmdi-notifications"></i> <span>notifications</span></a>
            </div>
          </div>

          <h4>Person</h4>
          <hr>
          
          <div class="row">
            <div class="icon col-sm-3" data-code="f1ff" data-name="account-add">
              <a href="javascript:void();"><i class="zmdi zmdi-account-add"></i> <span>account-add</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f200" data-name="account-box-mail">
              <a href="javascript:void();"><i class="zmdi zmdi-account-box-mail"></i> <span>account-box-mail</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f201" data-name="account-box-o">
              <a href="javascript:void();"><i class="zmdi zmdi-account-box-o"></i> <span>account-box-o</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f202" data-name="account-box-phone">
              <a href="javascript:void();"><i class="zmdi zmdi-account-box-phone"></i> <span>account-box-phone</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f203" data-name="account-box">
              <a href="javascript:void();"><i class="zmdi zmdi-account-box"></i> <span>account-box</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f204" data-name="account-calendar">
              <a href="javascript:void();"><i class="zmdi zmdi-account-calendar"></i> <span>account-calendar</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f205" data-name="account-circle">
              <a href="javascript:void();"><i class="zmdi zmdi-account-circle"></i> <span>account-circle</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f206" data-name="account-o">
              <a href="javascript:void();"><i class="zmdi zmdi-account-o"></i> <span>account-o</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f207" data-name="account">
              <a href="javascript:void();"><i class="zmdi zmdi-account"></i> <span>account</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f208" data-name="accounts-add">
              <a href="javascript:void();"><i class="zmdi zmdi-accounts-add"></i> <span>accounts-add</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f209" data-name="accounts-alt">
              <a href="javascript:void();"><i class="zmdi zmdi-accounts-alt"></i> <span>accounts-alt</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f20a" data-name="accounts-list-alt">
              <a href="javascript:void();"><i class="zmdi zmdi-accounts-list-alt"></i> <span>accounts-list-alt</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f20b" data-name="accounts-list">
              <a href="javascript:void();"><i class="zmdi zmdi-accounts-list"></i> <span>accounts-list</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f20c" data-name="accounts-outline">
              <a href="javascript:void();"><i class="zmdi zmdi-accounts-outline"></i> <span>accounts-outline</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f20d" data-name="accounts">
              <a href="javascript:void();"><i class="zmdi zmdi-accounts"></i> <span>accounts</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f20e" data-name="face">
              <a href="javascript:void();"><i class="zmdi zmdi-face"></i> <span>face</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f20f" data-name="female">
              <a href="javascript:void();"><i class="zmdi zmdi-female"></i> <span>female</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f210" data-name="male-alt">
              <a href="javascript:void();"><i class="zmdi zmdi-male-alt"></i> <span>male-alt</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f211" data-name="male-female">
              <a href="javascript:void();"><i class="zmdi zmdi-male-female"></i> <span>male-female</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f212" data-name="male">
              <a href="javascript:void();"><i class="zmdi zmdi-male"></i> <span>male</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f213" data-name="mood-bad">
              <a href="javascript:void();"><i class="zmdi zmdi-mood-bad"></i> <span>mood-bad</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f214" data-name="mood">
              <a href="javascript:void();"><i class="zmdi zmdi-mood"></i> <span>mood</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f215" data-name="run">
              <a href="javascript:void();"><i class="zmdi zmdi-run"></i> <span>run</span></a>
            </div>
            <div class="icon col-sm-3" data-code="f216" data-name="walk">
              <a href="javascript:void();"><i class="zmdi zmdi-walk"></i> <span>walk</span></a>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </div><!--End Row-->

  <!--start overlay-->
		  <div class="overlay toggle-menu"></div>
		<!--end overlay-->
  
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
	<!--Start footer-->
	<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2018 Dashtreme Admin
        </div>
      </div>
    </footer>
	<!--End footer-->
	
	<!--start color switcher-->
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">

      <p class="mb-0">Gaussion Texture</p>
      <hr>
      
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>

      <p class="mb-0">Gradient Background</p>
      <hr>
      
      <ul class="switcher">
        <li id="theme7"></li>
        <li id="theme8"></li>
        <li id="theme9"></li>
        <li id="theme10"></li>
        <li id="theme11"></li>
        <li id="theme12"></li>
		<li id="theme13"></li>
        <li id="theme14"></li>
        <li id="theme15"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->
   
  </div><!--End wrapper-->


  <!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
	
  <!-- simplebar js -->
  <script src="assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- sidebar-menu js -->
  <script src="assets/js/sidebar-menu.js"></script>
  
  <!-- Custom scripts -->
  <script src="assets/js/app-script.js"></script>
	
</body>
</html>
