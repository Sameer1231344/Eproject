<?php



$one =$_GET["one"];
$two=$_GET["two"];
$three =$_GET["three"];
$four=$_GET["four"];
$five=$_GET["five"];
$six=$_GET["six"];
$seven=$_GET["seven"];
$eigth=$_GET["eigth"];
$nine=$_GET["nine"];
$zero=$_GET["zero"];
$a=$_GET["addbtn"];
$s=$_GET["subbtn"];
$m=$_GET["multbtn"];
$d=$_GET["divbtn"];
$dec=$_GET["decbtn"];
$eq=$_GET["btnsubmit"];
$clr=$_GET["clrbtn"];
$screen=$_GET["screen"];


?>