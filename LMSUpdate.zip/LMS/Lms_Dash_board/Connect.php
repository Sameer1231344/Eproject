<?php

$con=mysqli_connect("localhost","root","","lms");
if(!$con)
{   echo"<script>alert('Connection Failed')</script>";
}
else{
    
}

?>